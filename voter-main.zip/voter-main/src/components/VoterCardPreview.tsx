
"use client";

import React from 'react';
import ReactQRCode from 'react-qr-code';

interface VoterCardPreviewProps {
  formData: any;
}

export function VoterCardPreview({ formData }: VoterCardPreviewProps) {
  const photoUrl = formData.photoUrl || 'https://picsum.photos/seed/voter1/200/250';
  
  const getGenderText = () => {
    const isFemale = formData.gender === 'Female';
    const isMale = formData.gender === 'Male';
    const hindi = isFemale ? 'महिला' : isMale ? 'पुरुष' : 'अन्य';
    const english = isFemale ? 'Female' : isMale ? 'Male' : 'Other';
    return `${hindi} / ${english}`;
  };

  const getDobOrAgeText = () => {
    if (formData.inputMode === 'dob' && formData.dob) {
      const date = new Date(formData.dob);
      if (!isNaN(date.getTime())) {
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        return `${day}/${month}/${year}`;
      }
    }
    return formData.age || '30';
  };

  const relationLabelHindi = formData.relation === 'Husband' ? 'पति का नाम' : 
                            formData.relation === 'Mother' ? 'माता का नाम' : 'पिता का नाम';
  const relationLabelEnglish = formData.relation === 'Husband' ? "Husband's Name" : 
                               formData.relation === 'Mother' ? "Mother's Name" : "Father's Name";

  const assemblyTextHindi = `${formData.acNumber || '286'} - ${formData.asmblyNameLocal || 'बहराइच'}`;
  const assemblyTextEnglish = `${formData.acNumber || '286'} - ${formData.asmblyName || 'BAHRAICH'}`;

  const epicNo = formData.epicNo || 'UAF3763489';

  return (
    <div className="voter-preview-wrapper print:m-0">
      <style jsx>{`
        .voter-preview-wrapper {
          width: 100%;
          max-width: 1000px;
          margin: 0 auto;
          overflow: visible;
        }

        #voter-card-background {
          left: 0px;
          top: 0px;
          position: relative;
          width: 2081px;
          height: 666px;
          overflow: hidden;
          z-index: 0;
          background: #fff;
          transform-origin: top left;
          transform: scale(var(--preview-scale, 0.45));
        }

        #Layer14 {
          left: 9px;
          top: 24px;
          position: absolute;
          width: 1023px;
          height: 622px;
          z-index: 2;
          background-image: url('/Layer14.png');
          background-size: cover;
        }

        #Layer15 {
          left: 1045px;
          top: 23px;
          position: absolute;
          width: 1010px;
          height: 620px;
          z-index: 3;
          background-image: url('/Layer15.png');
          background-size: cover;
        }

        #Layer13 {
          left: 38px;
          top: 254px;
          position: absolute;
          width: 255px;
          height: 334px;
          z-index: 10;
          overflow: hidden;
          border: 1px solid #000;
        }
        #Layer13 img { width: 100%; height: 100%; object-fit: cover; }

        #Layer5 {
          left: 45px;
          top: 194px;
          position: absolute;
          width: 400px;
          height: 45px;
          z-index: 11;
          color: #000000;
          font-weight: 900;
          font-family: 'Arial Rounded MT Bold', 'Helvetica Rounded', Arial, sans-serif;
          font-size: 34px;
        }

        #Layer2 {
          left: 313px;
          top: 262px;
          position: absolute;
          width: 600px;
          height: 80px;
          z-index: 14;
          line-height: 1.2;
          color: #000;
        }
        .name-hindi { display: block; font-weight: 700; font-size: 28px; }
        .name-eng-label { font-weight: 700; font-size: 26px; }
        .name-eng-val { font-weight: 500; font-size: 26px; text-transform: uppercase; }

        #Layer3 {
          left: 311px;
          top: 349px;
          position: absolute;
          width: 600px;
          height: 85px;
          z-index: 13;
          line-height: 1.2;
          color: #000;
        }
        .rel-hindi { display: block; font-weight: 700; font-size: 28px; }
        .rel-eng-label { font-weight: 700; font-size: 26px; }
        .rel-eng-val { font-weight: 500; font-size: 26px; text-transform: uppercase; }

        #Layer4 {
          left: 311px;
          top: 436px;
          position: absolute;
          width: 600px;
          height: 127px;
          z-index: 12;
          line-height: 1.4;
          color: #000;
        }
        .gender-row { font-size: 26px; font-weight: 700; margin-bottom: 8px; }
        .dob-row-hindi { display: block; font-weight: 700; font-size: 20px; }
        .dob-row-eng { font-weight: 700; font-size: 20px; }
        .dob-val { font-weight: 500; }

        #Layer6 {
          left: 874px;
          top: 186px;
          position: absolute;
          width: 89px;
          height: 110px;
          z-index: 10;
          filter: grayscale(100%) opacity(0.5);
          overflow: hidden;
        }
        #Layer6 img { width: 100%; height: 100%; object-fit: cover; }

        #Layer7 {
          left: 958px;
          top: 177px;
          position: absolute;
          width: 300px;
          height: 25px;
          z-index: 10;
          font-size: 16px;
          color: #000000;
          font-weight: bold;
          transform: rotate(90deg);
          transform-origin: top left;
          white-space: nowrap;
        }

        #Layer8 {
          left: 1082px;
          top: 151px;
          position: absolute;
          width: 281px;
          height: 292px;
          z-index: 8;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #fff;
          padding: 10px;
        }

        #Layer9 {
          left: 1403px;
          top: 180px;
          position: absolute;
          width: 640px;
          height: auto;
          min-height: 150px;
          z-index: 10;
          font-size: 32px;
          line-height: 1.3;
          color: #000;
        }
        .addr-hindi { font-weight: 700; display: block; margin-bottom: 5px; font-size: 34px; }
        .addr-eng { font-weight: 500; display: block; font-size: 30px; }

        #Layer12 {
          left: 1399px;
          top: 386px;
          position: absolute;
          width: 600px;
          height: auto;
          z-index: 10;
          font-size: 28px;
          line-height: 1.4;
          color: #000;
        }

        .epic-bottom-back {
           position: absolute;
           left: 1082px;
           top: 455px;
           color: #000000;
           font-weight: 900;
           font-size: 34px;
           letter-spacing: -1px;
           font-family: 'Arial Rounded MT Bold', 'Helvetica Rounded', Arial, sans-serif;
           z-index: 20;
           width: 300px;
           text-align: center;
        }

        @media screen and (max-width: 1024px) {
          .voter-preview-wrapper { --preview-scale: 0.4; }
        }
        @media screen and (max-width: 768px) {
          .voter-preview-wrapper { --preview-scale: 0.28; }
        }
      `}</style>

      <div id="voter-card-background">
        <div id="Layer14" />
        <div id="Layer13">
          <img src={photoUrl} alt="Voter" />
        </div>

        <div id="Layer5">{epicNo}</div>

        <div id="Layer2">
          <span className="name-hindi">नाम: {formData.nameLocal || 'शैलेंद्रसिंह'}</span>
          <div>
            <span className="name-eng-label">Name: </span>
            <span className="name-eng-val">{formData.name || 'SHAILENDRASINGH'}</span>
          </div>
        </div>

        <div id="Layer3">
          <span className="rel-hindi">{relationLabelHindi}: {formData.fatherHusbandNameLocal || 'राम शंकर सिंह'}</span>
          <div>
            <span className="rel-eng-label">{relationLabelEnglish}: </span>
            <span className="rel-eng-val">{formData.fatherHusbandName || 'RAM SHANKARSINGH'}</span>
          </div>
        </div>

        <div id="Layer4">
          <div className="gender-row">लिंग / Gender: {getGenderText()}</div>
          <span className="dob-row-hindi">जन्म तिथि / आयु:</span>
          <div className="dob-row-eng">
            Date of Birth / Age: <span className="dob-val">{getDobOrAgeText()}</span>
          </div>
        </div>

        <div id="Layer6">
          <img src={photoUrl} alt="Ghost" />
        </div>

        <div id="Layer7">{epicNo}</div>

        <div id="Layer15" />
        <div id="Layer8">
          <ReactQRCode value={epicNo} size={260} />
        </div>

        <div id="Layer9">
          <span className="addr-hindi">पता: {formData.addressLocal || 'त्रिकोलिया, पयागपुर, बहराइच, उत्तर प्रदेश - 271871'}</span>
          <span className="addr-eng"><span className="font-bold">Address: </span>{formData.address || 'trikoliya payagpur, bahraich, uttar pradesh - 271871'}</span>
        </div>

        <div id="Layer12">
          <div className="font-bold">निर्वाचक रजिस्ट्रीकरण अधिकारी, {assemblyTextHindi}</div>
          <div className="mt-1"><span className="font-bold">Electoral Registration Officer, </span>{assemblyTextEnglish}</div>
        </div>

        <div className="epic-bottom-back">
          {epicNo}
        </div>
      </div>
    </div>
  );
}
